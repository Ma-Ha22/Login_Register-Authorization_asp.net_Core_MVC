﻿using Models;


namespace DayOne_App.ViewModel
{
    public static class UserExtention
    {
      public static User toModel(this RegisterViewModel _regVM)
        {
            return new User
            {
                FullName = _regVM.FullName,
                UserName = _regVM.UserName,
                NationalID = _regVM.NationalID,
                PhoneNumber = _regVM.PhoneNumber,
                Email = _regVM.Email,
            };
        }
    }
}
