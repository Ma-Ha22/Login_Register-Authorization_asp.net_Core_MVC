﻿using Models;

namespace DayOne_App.Repository
{
    public class ProductManager: Manager<Product>
    {
        public ProductManager(MyDBContext _db) : base(_db) { }

        public Product GetOneByID(int id)
        {
            return GetAll().Where(i => i.ID == id).FirstOrDefault();
        }
        public void Edit(Product newPrd, int id)
        {
            Product oldprod = GetOneByID(id);
            oldprod.Name = newPrd.Name;
            oldprod.Price = newPrd.Price;
            oldprod.Quantity = newPrd.Quantity;
            oldprod.CategoryID = newPrd.CategoryID;
            oldprod.Description = newPrd.Description;

            Edit(oldprod);         
        }
        public void Delete(int id)
        {
            Product product = GetOneByID(id);
            Delete(product);
            
        }

    }
}
