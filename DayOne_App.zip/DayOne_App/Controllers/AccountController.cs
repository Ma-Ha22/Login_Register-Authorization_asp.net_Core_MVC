﻿using DayOne_App.Repository;
using DayOne_App.ViewModel;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace DayOne_App.Controllers
{
    public class AccountController: Controller
    {
       public  UserAccountManager userAccountManager;
       public AccountController(UserAccountManager _userMngr) 
        {
             userAccountManager = _userMngr;
        }

        [HttpGet]
        public IActionResult Login(string ReturnUrl = "/") 
        {
            var veiwModel = new LoginViewModel() { ReturnUrl = ReturnUrl };
            return View(veiwModel);
        
        }
        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel veiwModel)
        {
            if (ModelState.IsValid)
            {
                var res = await userAccountManager.Login(veiwModel);
                if (res.Succeeded)
                {
                    return RedirectToAction("GetAll", "Product");
                }
                else
                {
                    ModelState.AddModelError("", "Invaild User Name Or Password");
                    return View();
                }
            }
            return View();
        }

        [HttpGet]
        public IActionResult Register() 
        
        { 
            return View(); 
        
        }
        [HttpPost]
        public async Task<IActionResult> Register(RegisterViewModel _regVM)

        {
            if(ModelState.IsValid)
            {
                IdentityResult res = await userAccountManager.SignUp(_regVM);
                if (res.Succeeded)
                {
                    return RedirectToAction("Login");
                }
                else
                {
                    foreach (var item in res.Errors)
                    {
                        ModelState.AddModelError("", item.Description);
                    }
                    return View();
                }
            }
            return View();

        }
    
        
    
    }
}

