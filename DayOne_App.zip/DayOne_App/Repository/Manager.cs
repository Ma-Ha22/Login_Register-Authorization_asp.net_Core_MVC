﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Models;
using System.Collections.Generic;

namespace DayOne_App.Repository
{
    public class Manager<T> where T: class
    {
        private readonly MyDBContext _dbContext;
        private readonly DbSet<T> _dbSet;
        public Manager(MyDBContext _db)
        {
            this._dbContext = _db;
            this._dbSet = _dbContext.Set<T>();
        }
        public EntityEntry<T> Add(T Entry) => _dbSet.Add(Entry);

        public IQueryable<T> GetAll()
        {
            return _dbSet.AsQueryable();
        }

        public EntityEntry<T> Edit(T Entry) => _dbSet.Update(Entry);

        public EntityEntry<T> Delete(T Entry)
        {
            return _dbSet.Remove(Entry);
        }
        

    }
}
