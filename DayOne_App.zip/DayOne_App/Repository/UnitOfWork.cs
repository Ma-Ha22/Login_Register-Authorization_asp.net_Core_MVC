﻿using Models;

namespace DayOne_App.Repository
{
    public class UnitOfWork
    {
        public MyDBContext _dbContext { get; set; }
        public UnitOfWork(MyDBContext _db) {
            _dbContext = _db;
        }
        public void Commit()
        {
            _dbContext.SaveChanges();
        }
    }
}
