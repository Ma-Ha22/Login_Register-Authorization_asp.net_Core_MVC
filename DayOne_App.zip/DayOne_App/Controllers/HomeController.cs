﻿using Microsoft.AspNetCore.Mvc;

namespace DayOne_App.Controllers
{
    public class HomeController: Controller
    {
        public ViewResult Index() { return View(); }
    }
}

