﻿
using DayOne_App.Repository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

using Models;

namespace DayOne_App.Controllers
{
    [Authorize]
    public class ProductController: Controller
    {
        ProductManager productManager;
        UnitOfWork unitOfWork;
        //public MyDBContext db = new MyDBContext();
        public ProductController(ProductManager _productManager,UnitOfWork _unitOfWork)
        {
            productManager = _productManager;
            unitOfWork = _unitOfWork;
        }
        public IActionResult GetAll()
        {
            List<Product> list = productManager.GetAll().ToList();

            return View(list);
        }

        //[Route("details/{id}")]
        public IActionResult GetDetails(int id) { 
            Product product = productManager.GetOneByID(id);
            return View(product);
        }
        public IActionResult Delete(int id)
        {
            productManager.Delete(id);        
            unitOfWork.Commit();
            return RedirectToAction("GetAll");

        }
        [HttpPost]
        public IActionResult AddProduct(AddProduct addProduct)
        {
            Product p = new Product();
            p.Name = addProduct.Name;
            p.Price = addProduct.Price;
            p.Quantity = addProduct.Quantity;
            p.Description = addProduct.Description;
            p.CategoryID = addProduct.CategoryID;
            productManager.Add(p);
            unitOfWork.Commit();
            return View();
        }
        [HttpGet]
        public IActionResult AddProduct()
        {
            Product p = new Product();
            return View();
        }
        public IActionResult EditProduct(int id)
        {
            return View();
        }
        //public IActionResult EditProduct()
    }
}
