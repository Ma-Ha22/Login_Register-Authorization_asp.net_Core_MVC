﻿
using DayOne_App.Repository;
using Microsoft.Extensions.FileProviders;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Models;
using Microsoft.AspNetCore.Identity;

namespace DayOne_App
{
   public class Program
    {
        static void Main()
        {
            WebApplicationBuilder Bldr = WebApplication.CreateBuilder();


            Bldr.Services.AddIdentity<User, IdentityRole>(i => {
                i.User.RequireUniqueEmail = true;
                i.SignIn.RequireConfirmedPhoneNumber = false;
               
                i.SignIn.RequireConfirmedEmail = false;
                i.SignIn.RequireConfirmedAccount = false;
            })
                .AddEntityFrameworkStores<MyDBContext>();
            Bldr.Services.AddScoped(typeof(MyDBContext));
            Bldr.Services.AddScoped(typeof(UnitOfWork));
            Bldr.Services.AddScoped(typeof(ProductManager));
            Bldr.Services.AddScoped(typeof(UserAccountManager));
            //Bldr.Services.AddScoped((typeof(AddIdentity));
            Bldr.Services.AddControllersWithViews();
            var app = Bldr.Build();
            
            
            //app.UseMiddleware<ProductMiddleWarecs>();
            //app.UseMiddleware<CategoryMiddleWare>();
            app.UseStaticFiles(new StaticFileOptions()
            {
                FileProvider = new PhysicalFileProvider(Directory.GetCurrentDirectory() + "/Views/Shared"),
                RequestPath = ""

            }) ;

            app.MapControllerRoute("Default", "{Controller=Product}/{Action=GetAll}/{id?}");


            app.Run();

        }
    }
}