﻿using Models;

namespace DayOne_App
{
    public class CategoryMiddleWare
    {


            public RequestDelegate next;
            public CategoryMiddleWare(RequestDelegate _next)
            {
                this.next = _next;
            }
            public async Task InvokeAsync(HttpContext context)
            {


                MyDBContext db = new MyDBContext();
                if (context.Request.Path == "/Category")
                {
                    await context.Response.WriteAsJsonAsync(db.Categories.ToList());
                }
                else if (context.Request.Path == "/CategoryId")
                {
                    int ID = int.Parse(context.Request.Query["ID"]);
                    var cate = db.Categories.FirstOrDefault(x => x.ID == ID);
                    await context.Response.WriteAsync(cate.Name);
                }





                await next(context);
            }
        }
    }





