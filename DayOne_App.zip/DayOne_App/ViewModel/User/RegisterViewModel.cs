﻿using System.ComponentModel.DataAnnotations;

namespace DayOne_App.ViewModel
{
    public class RegisterViewModel
    {
        [Required, StringLength(15,MinimumLength =2)]
        public string FullName { get; set; }

        [Required, StringLength(15, MinimumLength = 5)]
        public string UserName { get; set; }

        public string PhoneNumber { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required, StringLength(14, MinimumLength = 14)]
        public string NationalID { get; set; }

        [Required, StringLength(10, MinimumLength = 8)]

        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Required]
        [Compare("Password")]
        [DataType(DataType.Password)]
        public string PasswordConfirmed { get; set; }

    }
}
