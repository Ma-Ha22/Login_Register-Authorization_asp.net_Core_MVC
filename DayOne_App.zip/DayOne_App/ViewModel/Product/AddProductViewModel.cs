﻿using System.ComponentModel.DataAnnotations;

namespace DayOne_App.ViewModel.Product
{
    public class AddProductViewModel
    {
        public int ID { get; set; }
        public string Name { get; set;}
        public string Description { get; set; }
        public double Price { get; set; }
        public int Quantity { get; set; }

        [Display(Name = "Choose Product Category")]
        public int CategoryID { get; set; }
        public IFormFileCollection Images { get; set; }
        public List<string> ImagesURL { get; set; } = new List<string>();
        public bool KeepImages { get; set; } = true;

    }
}
