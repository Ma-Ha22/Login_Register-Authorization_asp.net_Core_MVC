﻿using System.ComponentModel.DataAnnotations;

namespace DayOne_App.ViewModel
{
    public class Validation: ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            string temp = value?.ToString();
            if (string.IsNullOrEmpty(temp))
            {
                return new ValidationResult("This input is required");
            }
           
            return ValidationResult.Success;
        }
    }
}
