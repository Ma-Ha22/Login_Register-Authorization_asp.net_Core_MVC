﻿using Models;

using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using DayOne_App.ViewModel;

namespace DayOne_App.Repository
{
    public class UserAccountManager: Manager<User>
    {
        UserManager<User> userManager;
        SignInManager<User> signInManager;  

       public UserAccountManager(MyDBContext myDB, SignInManager<User> _signInManager, UserManager<User> _userManager) :base (myDB)
        {
            userManager = _userManager;
            signInManager = _signInManager;
        }
        public async Task<IdentityResult> SignUp(RegisterViewModel _regVM)
        {
            return await userManager.CreateAsync(_regVM.toModel(), _regVM.Password);
        }
        public async Task<SignInResult> Login(LoginViewModel _lognVM)
        {
            return await signInManager.PasswordSignInAsync(_lognVM.Email, _lognVM.Password, _lognVM.RememberMe, false);        
        }
        public async void SignOut()
        {
           await signInManager.SignOutAsync();
        }

    }
}
